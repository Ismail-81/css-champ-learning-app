import "./Css/App.css";
import RoutePage from "./RoutePage.jsx";

function App() {
  

  return (
    <>
      <link
        href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Space+Grotesk:wght@400;700&display=swap"
        rel="stylesheet"/>
        
          <RoutePage />
        
    </>
  );
}
export default App;
